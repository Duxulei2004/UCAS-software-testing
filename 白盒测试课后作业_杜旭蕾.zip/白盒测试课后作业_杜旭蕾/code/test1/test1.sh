clang -fprofile-instr-generate -fcoverage-mapping test.c -o test
inputs=("-1 0 5" "0 1 5" "-1 1 0" "0 0 0" "-1 0 0")
raw_files=""
for i in "${!inputs[@]}"; do
    echo "${inputs[$i]}" | LLVM_PROFILE_FILE="test$i.profraw" ./test
    raw_files+="test$i.profraw "
done
llvm-profdata merge -sparse $raw_files -o test.profdata
llvm-cov show ./test -instr-profile=test.profdata
llvm-cov report -show-region-summary=false ./test -instr-profile=test.profdata

