#include<stdio.h>
int main () {
	int a, b, c, d;
	printf("Please input the value of a b c, and press enter\n");
	scanf("%d %d %d", &a, &b, &c);
	if (a<0 && (b>0 || c==5)){//s1
		printf("d=a\n");
		d = a;//s2

	}else{//s3
		printf("d=b\n");
		d = b;//s4
	}
	if (d > 0 || a>=0){//s5
		printf("d--\n");
		d--;//s6
	}
	return d;//s7
}

// S1 = a<0 && (b>0 || c==5)
// S2 = d > 0 || a>=0


// x1 = a<0
// x2 = b>0
// x3 = c==5
// x4 = d>0

// d > 0 等价于 !(a<0 && (b>0 || c==5)) && b > 0
// x4 = ~x1 || x2
// S1 = x1 && (x2 || x3)
// S2 = x4 || ~x1
