clang -fprofile-instr-generate -fcoverage-mapping test.c -o test

inputs=("-1+(-1+1)+1/1*1-(1*1)+(-1)" "6--**-3" "(-a)" ")*" ")-" "1a1" "1+(1+1)")

raw_files=""


for i in "${!inputs[@]}"; do
    echo "Running test case $i: '${inputs[i]}'"
    echo "${inputs[i]}" | LLVM_PROFILE_FILE="test$i.profraw" ./test
    echo " "
    raw_files+="test$i.profraw "
done

llvm-profdata merge -sparse $raw_files -o test.profdata

llvm-cov show ./test -instr-profile=test.profdata

llvm-cov report -show-region-summary=false ./test -instr-profile=test.profdata
