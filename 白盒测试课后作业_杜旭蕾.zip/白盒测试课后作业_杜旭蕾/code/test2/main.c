for(i = 0; str[i] != '\0'; i ++) { 
   
		if(i == 0 && str[i] == '-') { //s1
            //s2
			v[t++] = str[i];
		}
		else if(str[i] == '(' && str[i+1] == '-') { //s3
            //s4
            //s4-1
			i ++;
			v[t++] = str[i++];
			while(str[i] >= '0' && str[i] <= '9') { //s4-2
                //s4-3
				v[t] = str[i];
				t ++;
				i ++;
			}
			Inshuju(&data, atoi(v));//s4-4
			while(t > 0) { //s4-5
                //s4-6
				v[t] = 0;
				t --;
			}
			if(str[i] != ')') { //s4-7 
                //s4-8
				i --;
				Infuhao(&symbol, '(');
			}
		}
		else if(str[i] >= '0' && str[i] <= '9') {//s5
            //s6 
			while(str[i] >= '0' && str[i] <= '9') { //s6-1
                //s6-2
				v[t] = str[i];
				t ++;
				i ++;
			}
			Inshuju(&data, atoi(v));//s6-3
			while(t > 0) { //s6-4
                //s6-5
				v[t] = 0;
				t --;
			}
			i --;//s6-6
		}
		else { //s7
            //s8
			if(symbol.top == -1) //s8-1
			{ 
				Infuhao(&symbol, str[i]);//s8-2
			}
			else if(judge(str[i]) == 1) { //s8-3
				Infuhao(&symbol, str[i]);//s8-4
			}
			else if(judge(str[i]) == 2) { //s8-5
                //s8-6
				if(judge(Randfuhao(&symbol)) == 1) { //a1
					Infuhao(&symbol, str[i]);//a2
				}
				else if(judge(Randfuhao(&symbol)) == 2) { //a3
					while(symbol.top >= 0 && data.top >= 1) { //a4
						//a5
                        v2 = Putshuju(&data);
						v1 = Putshuju(&data);
						sum = Math(v1, v2, Putfuhao(&symbol));
						Inshuju(&data, sum);  
					}
					Infuhao(&symbol, str[i]); //a6
				}
				else if(judge(Randfuhao(&symbol)) == 3) { //a7
    
					while(symbol.top >= 0 && data.top >= 1) { //a8
						//a9
                        v2 = Putshuju(&data);
						v1 = Putshuju(&data);
						sum = Math(v1, v2, Putfuhao(&symbol));
						Inshuju(&data, sum); 
					}
					Infuhao(&symbol, str[i]); //a10
				}
			}
			else if(judge(str[i]) == 3) { //s8-7
                //s8-8
				if(judge(Randfuhao(&symbol)) == 1) { //b1
					Infuhao(&symbol, str[i]); //b2
				}
				else if(judge(Randfuhao(&symbol)) == 2) { //b3
					Infuhao(&symbol, str[i]); //b4
				}
				else if(judge(Randfuhao(&symbol)) == 3) { //b5 
					while(symbol.top >= 0 && data.top >= 1) { //b6
						//b7
                        v2 = Putshuju(&data);
						v1 = Putshuju(&data);
						sum = Math(v1, v2, Putfuhao(&symbol));
						Inshuju(&data, sum); 
					}
					Infuhao(&symbol, str[i]); //b8
				}
			}
			else if(judge(str[i]) == 4) { //s8-9
                //s8-10
				do { //c1
                    //c2
					v2 = Putshuju(&data);
					v1 = Putshuju(&data);
					sum = Math(v1, v2, Putfuhao(&symbol));
					Inshuju(&data, sum); 
				}while(judge(Randfuhao(&symbol)) != 1);//c3
				Putfuhao(&symbol); //c4
			} 		
		}
	}
    free(str); //s9
