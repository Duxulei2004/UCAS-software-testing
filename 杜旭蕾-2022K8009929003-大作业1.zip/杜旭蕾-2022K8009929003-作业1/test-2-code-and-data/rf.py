from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def calculate_deed_tax(BUYER_is_first_purchase, HOUSE_total_area, HOUSE_total_price, value_added_tax):
    if HOUSE_total_area <= 0 or HOUSE_total_price <= 0:
        return None
    
    if not BUYER_is_first_purchase:  # 二套购房，税率3%
        deed_tax = (HOUSE_total_price - value_added_tax) * 0.03
    elif BUYER_is_first_purchase and HOUSE_total_area <= 90:  # 首套购房90平米(含)以下，税率1%
        deed_tax = (HOUSE_total_price - value_added_tax) * 0.01
    else:  # 首套购房90平米以上，税率1.5%
        deed_tax = (HOUSE_total_price - value_added_tax) * 0.015
    
    return deed_tax


# 计算增值税
def calculate_value_added_tax(SELLER_certificate_time, HOUSE_is_urban, HOUSE_total_price):
    if SELLER_certificate_time <= 0 or HOUSE_total_price <= 0:
        return None
    
    if SELLER_certificate_time >= 2:  # 房产证满两年，免增值税
        return 0
    
    if SELLER_certificate_time < 2 and HOUSE_is_urban:  # 不满两年，城区
        return HOUSE_total_price / 1.05 * 0.05
    
    if SELLER_certificate_time < 2 and not HOUSE_is_urban:  # 不满两年，郊区
        return HOUSE_total_price / 1.05 * 0.05

def calculate_value_tax(SELLER_certificate_time, HOUSE_total_price):
    if SELLER_certificate_time <= 0 or HOUSE_total_price <= 0:
        return None
    
    if SELLER_certificate_time >= 2:  # 房产证满两年，免增值税
        return 0

    if SELLER_certificate_time < 2 :  # 不满两年，郊区
        return HOUSE_total_price / 1.05 * 0.05


# 计算个税
def calculate_income_tax(HOUSE_total_price, HOUSE_original_price, SELLER_certificate_time, SELLER_is_only_house, value_added_tax):
    if HOUSE_total_price <= 0 or (HOUSE_original_price != None and HOUSE_original_price <= 0) or SELLER_certificate_time <= 0 :
        return None
    elif SELLER_certificate_time >= 5 and SELLER_is_only_house:  # 满五年，唯一住房免个税
        return 0
    
    elif HOUSE_original_price == None or HOUSE_original_price <= 0:  # 未知原值
        return HOUSE_total_price * 0.01
    elif HOUSE_original_price > 0:  # 已知原值
        income_tax = (HOUSE_total_price * 0.9 - HOUSE_original_price - value_added_tax) * 0.2
        if income_tax < 0:
            income_tax = 0
    return income_tax


def test(price_per_square_meter,buyer_is_first_purchase, seller_is_only_house, seller_certificate_time, house_total_area, house_total_price, house_original_price,deed_tax, value_added_tax_result, income_tax):
    # 配置 WebDriver，假设使用 Chrome 浏览器
    driver = webdriver.Chrome() 

    # 打开目标网站
    driver.get('https://newhouse.fang.com/jsq/sf.htm')  # 替换为实际的网址
    # 使用XPath定位到 "二手房" 选项的 <i> 标签
    second_hand_house_option = driver.find_element(By.XPATH, '//span[text()="二手房"]/i')
    # 点击 "二手房" 选项
    second_hand_house_option.click()

    # 选择卖房家庭唯一
    family_status = seller_is_only_house # 0 代表非唯一，1 代表唯一

    # family_status_dropdown = driver.find_element(By.CSS_SELECTOR, "span[data-reactid='.0.0.0:$2.1.1']")
    # family_status_dropdown.click()

    if (family_status == 1):
        family_status_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//li[span[contains(text(), '卖方家庭唯一住房')]]//span[@class='fangshi']/i[@class='on']"))
        )
    else: 
        family_status_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//li[span[contains(text(), '卖方家庭唯一住房')]]//span[@class='fangshi']/i[not(@class='on')]"))
        )
    family_status_option.click()

    # 输入距离上次交易时间：5 2 0
    #<span class="selectItemIcon" data-reactid=".0.0.0:$3.1.1"></span>
    if seller_certificate_time >= 5:
        # 使用 XPath 通过文本“房产购置满5年”来定位到“满5年”选项的父级元素，然后点击“满5年”
        certificate_time_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//li[span[contains(text(), '房产购置满5年')]]//span[@class='fangshi']/i[@class='on']"))
        )
    elif seller_certificate_time >= 2:
        # 使用 XPath 定位包含“房产购置满5年”文本的父元素，并选择“满2年”选项
        certificate_time_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//li[span[contains(text(), '房产购置满5年')]]//span[@class='fangshi'][contains(., '满2年')]/i"))
        )
    else:
        # 使用 XPath 定位包含“房产购置满5年”文本的父元素，并选择“不满两年”选项
        certificate_time_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//li[span[contains(text(), '房产购置满5年')]]//span[@class='fangshi'][contains(., '不满两年')]/i"))
        )
    certificate_time_option.click()

    # 输入买房家庭首套
    if buyer_is_first_purchase == 1:
        # 使用 XPath 定位包含“买房家庭首次购房”文本的父元素，并选择“是”选项
        buyer_purchase_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//li[span[contains(text(), '买房家庭首次购房')]]//span[@class='fangshi'][contains(., '是')]/i"))
        )
    else:
        buyer_purchase_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//li[span[contains(text(), '买房家庭首次购房')]]//span[@class='fangshi'][contains(., '否')]/i"))
        )
    buyer_purchase_option.click()

    # 输入房屋面积
    area_input = driver.find_element(By.XPATH, '//input[@placeholder="请输入房屋面积"]')
    area_input.clear()
    area_input.send_keys(house_total_area)  # 填写面积（单位：平米）

    # 输入房屋总价
    per_input = driver.find_element(By.XPATH, '//input[@placeholder="请输入房屋单价"]')
    per_input.clear()
    per_input.send_keys(price_per_square_meter)  # 填写单价（单位：元/平米）

    total_price = house_total_price  # 总价（单位：万元）
    price_input = driver.find_element(By.XPATH, '//input[@placeholder="请输入房屋总价"]')
    price_input.clear()
    price_input.send_keys(total_price)  # 填写总价（单位：万元）


    # 输入房屋原值
    # 如果卖家不是唯一住房，需要填写原值
    if(seller_is_only_house == 0 or seller_certificate_time < 5):
        input_element = driver.find_element(By.XPATH, '//li[span[contains(text(), "计征方式")]]//input[@readonly="readonly"]')
        input_element.click()

        # 步骤 2：定位并点击 "差价" 选项
        # 等待“差价”选项可见
        price_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//ul[@class="option"]//li[text()="差价"]'))
        )
        price_option.click()
        original_price_input = driver.find_element(By.XPATH, '//input[@placeholder="请输入房屋原价"]')
        original_price_input.clear()
        original_price_input.send_keys(house_original_price)  # 填写原值（单位：万元）


    # 点击开始计算按钮
    calculate_button = driver.find_element(By.XPATH, '//span[@class="start" and text()="开始计算"]')
    calculate_button.click()


    time.sleep(3)

    # 获取结果

    total_zengzhi_tax = driver.find_element(By.XPATH, '//li[h3/text()="增值税："]//span').text

    qishui = driver.find_element(By.XPATH, '//li[h3/text()="契税："]//span').text

    geshui = driver.find_element(By.XPATH, '//li[h3/text()="个人所得税："]//span').text
    
    compare_and_print("契税", deed_tax, qishui)
    compare_and_print("增值税", value_added_tax_result, total_zengzhi_tax)
    compare_and_print("个税", income_tax, geshui)
    print("契税",qishui)
    print("增值税",total_zengzhi_tax)
    print("个税",geshui)
    print("-------------------")
    # 关闭浏览器
    driver.quit()
    return 1


def compare_and_print(discrepancy_name, calculated_value, web_value):
    """
    比较计算值和网页值，打印出不匹配的项
    """
    # 将网页读取的数值去掉 "￥" 并转成浮点数
    web_value_num = float(web_value.replace("￥", "")) if web_value != "免征" else 0
    # 只在不匹配时打印
    if (calculated_value == None):
        print("-------------------ERRROR-------------------")
        print(f"{discrepancy_name} 计算值报错，网页值 = {web_value}")
        print("-------------------ERRROR-------------------")
    elif abs(calculated_value - web_value_num) > 1:  # 允许微小误差
        print("-------------------ERRROR-------------------")
        print(f"{discrepancy_name} 不匹配：计算值 = {calculated_value}, 网页值 = {web_value}")
        print("-------------------ERRROR-------------------")


# 从文件读取数据
def read_data(file_path):
    data = []
    with open(file_path, 'r') as file:
        for line_num, line in enumerate(file, start=1):  # 使用enumerate获取行号，从1开始
            # 将每行数据按空格分割，转换为列表
            values = line.strip().split()

            if len(values) < 7:
                print(f"第{line_num}行数据不完整，跳过此行")
                continue  # 跳过格式不正确的行

            # 获取数据并转换为合适的类型
            buyer_is_first_purchase = int(values[0])  # 买房家庭首套
            house_total_area = float(values[1])  # 房屋面积
            house_total_price = float(values[2])  # 房屋总价
            seller_certificate_time = int(values[3])  # 房产证持有时间
            house_is_urban = int(values[4])  # 房屋区域是否在城区
            seller_is_only_house = int(values[5])  # 卖家是否唯一住房
            if(values[6] == "None"):
                house_original_price = None
            else:
                house_original_price = int(values[6])  # 房屋原值
            price_per_square_meter = float(values[7])  # 房屋单价
            #print("house_original_price",house_original_price)

            # 调用计算函数
            value_added_tax_result = calculate_value_added_tax(seller_certificate_time, house_is_urban, house_total_price)
            print(f"增值税: {value_added_tax_result}")
            
            value_tax = calculate_value_tax(seller_certificate_time, house_total_price)

            deed_tax = calculate_deed_tax(buyer_is_first_purchase, house_total_area, house_total_price, value_tax)
            print(f"契税: {deed_tax}")

            income_tax = calculate_income_tax(house_total_price, house_original_price, seller_certificate_time, seller_is_only_house, value_added_tax_result)
            print(f"个税: {income_tax}")
            
            if(house_original_price == None):
                house_original_price = 0       
            a = test(price_per_square_meter,buyer_is_first_purchase, seller_is_only_house, seller_certificate_time, house_total_area, house_total_price/10000, house_original_price/10000, deed_tax, value_added_tax_result, income_tax)

            print(f"处理了第{line_num}行数据")  # 打印处理了哪一行

            print()  # 打印空行分隔每一组数据

    return 1







# 假设文件路径为 data.txt
file_path = 'data.txt'
data = read_data(file_path)
