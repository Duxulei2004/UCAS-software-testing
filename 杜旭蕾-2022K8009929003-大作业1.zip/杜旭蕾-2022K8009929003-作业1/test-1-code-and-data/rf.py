from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def calculate_deed_tax(BUYER_is_first_purchase, HOUSE_total_area, HOUSE_total_price, value_added_tax):
    if HOUSE_total_area <= 0 or HOUSE_total_price <= 0:
        return None
    
    if not BUYER_is_first_purchase:  # 二套购房，税率3%
        deed_tax = (HOUSE_total_price - value_added_tax) * 0.03
    elif BUYER_is_first_purchase and HOUSE_total_area <= 90:  # 首套购房90平米(含)以下，税率1%
        deed_tax = (HOUSE_total_price - value_added_tax) * 0.01
    else:  # 首套购房90平米以上，税率1.5%
        deed_tax = (HOUSE_total_price - value_added_tax) * 0.015
    
    return deed_tax


# 计算增值税
def calculate_value_added_tax(SELLER_certificate_time, HOUSE_is_urban, HOUSE_total_price):
    if SELLER_certificate_time <= 0 or HOUSE_total_price <= 0:
        return None
    
    if SELLER_certificate_time >= 2:  # 房产证满两年，免增值税
        return 0
    
    if SELLER_certificate_time < 2 and HOUSE_is_urban:  # 不满两年，城区
        return HOUSE_total_price / 1.05 * 0.056
    
    if SELLER_certificate_time < 2 and not HOUSE_is_urban:  # 不满两年，郊区
        return HOUSE_total_price / 1.05 * 0.055

def calculate_value_tax(SELLER_certificate_time, HOUSE_total_price):
    if SELLER_certificate_time <= 0 or HOUSE_total_price <= 0:
        return None
    
    if SELLER_certificate_time >= 2:  # 房产证满两年，免增值税
        return 0

    if SELLER_certificate_time < 2 :  # 不满两年，郊区
        return HOUSE_total_price / 1.05 * 0.05


# 计算个税
def calculate_income_tax(HOUSE_total_price, HOUSE_original_price, SELLER_certificate_time, SELLER_is_only_house, value_added_tax):
    if HOUSE_total_price <= 0 or (HOUSE_original_price != None and HOUSE_original_price <= 0) or SELLER_certificate_time <= 0 :
        return None
    
    if SELLER_certificate_time >= 5 and SELLER_is_only_house:  # 满五年，唯一住房免个税
        return 0
    
    if HOUSE_original_price == None or HOUSE_original_price <= 0:  # 未知原值
        return HOUSE_total_price * 0.01
    if HOUSE_original_price > 0:  # 已知原值
        income_tax = (HOUSE_total_price * 0.9 - HOUSE_original_price - value_added_tax) * 0.2
        if income_tax < 0:
            income_tax = 0
    else:  # 未知原值
        income_tax = (HOUSE_total_price - value_added_tax) * 0.01
    
    return income_tax


def test(buyer_is_first_purchase, seller_is_only_house, seller_certificate_time, house_total_area, house_total_price, house_original_price,deed_tax, value_added_tax_result, income_tax):

    # 选择卖房家庭唯一
    family_status = seller_is_only_house # 0 代表非唯一，1 代表唯一

    family_status_dropdown = driver.find_element(By.CSS_SELECTOR, "span[data-reactid='.0.0.0:$2.1.1']")
    family_status_dropdown.click()

    if (family_status == 1):
        family_status_option = driver.find_element(By.CSS_SELECTOR, "li[data-reactid='.0.0.0:$2.1.2.$0']")  # 选择唯一
    else:
        family_status_option = driver.find_element(By.CSS_SELECTOR, "li[data-reactid='.0.0.0:$2.1.2.$1']")  # 选择非唯一
    family_status_option.click()

    # 输入距离上次交易时间：5 2 0
    #<span class="selectItemIcon" data-reactid=".0.0.0:$3.1.1"></span>
    certificate_time_dropdown = driver.find_element(By.CSS_SELECTOR, "span[data-reactid='.0.0.0:$3.1.1']")
    certificate_time_dropdown.click()
    if seller_certificate_time >= 5:
        certificate_time_option = driver.find_element(By.CSS_SELECTOR, "li[data-reactid='.0.0.0:$3.1.2.$0']")
    elif seller_certificate_time >= 2:
        certificate_time_option = driver.find_element(By.CSS_SELECTOR, "li[data-reactid='.0.0.0:$3.1.2.$1']")
    else:
        certificate_time_option = driver.find_element(By.CSS_SELECTOR, "li[data-reactid='.0.0.0:$3.1.2.$2']")
    certificate_time_option.click()

    # 输入买房家庭首套
    buyer_purchase_dropdown = driver.find_element(By.CSS_SELECTOR, "span[data-reactid='.0.0.0:$5.1.1']")
    buyer_purchase_dropdown.click()
    if buyer_is_first_purchase == 1:
        buyer_purchase_option = driver.find_element(By.CSS_SELECTOR, "li[data-reactid='.0.0.0:$5.1.2.$0']")
    else:
        buyer_purchase_option = driver.find_element(By.CSS_SELECTOR, "li[data-reactid='.0.0.0:$5.1.2.$1']")
    buyer_purchase_option.click()

    # 输入房屋面积
    area_input = driver.find_element(By.CSS_SELECTOR, "input[data-reactid='.0.0.0:$6.1.0']")
    area_input.clear()
    area_input.send_keys(house_total_area)  # 填写面积（单位：平米）

    # 输入房屋总价
    total_price = house_total_price  # 总价（单位：万元）
    price_input = driver.find_element(By.CSS_SELECTOR, "input[data-reactid='.0.0.0:$7.1.0']")
    price_input.clear()
    price_input.send_keys(total_price)  # 填写总价（单位：万元）

    # 输入房屋原值
    # 如果卖家不是唯一住房，需要填写原值
    if(seller_is_only_house == 0 or seller_certificate_time < 5):
        original_price_input = driver.find_element(By.CSS_SELECTOR, "input[data-reactid='.0.0.0:$8.1.0']")
        original_price_input.clear()
        original_price_input.send_keys(house_original_price)  # 填写原值（单位：万元）

    # 点击开始计算按钮
    calculate_button = driver.find_element(By.CSS_SELECTOR, "button[data-reactid='.0.0.1.0']")
    calculate_button.click()


    time.sleep(3)

    # 获取结果
    total_tax = driver.find_element(By.CSS_SELECTOR, "div.secondTaxValueItem[data-reactid='.0.1.0.1.$税费合计.1']").text
    #print("税费合计：", total_tax)

    zengzhi_tax = driver.find_element(By.CSS_SELECTOR, "div.secondTaxValueItem[data-reactid='.0.1.0.1.$增值税.1']").text

    qishui = driver.find_element(By.CSS_SELECTOR, "div.secondTaxValueItem[data-reactid='.0.1.0.1.$契税.1']").text
    


    geshui = driver.find_element(By.CSS_SELECTOR, "div.secondTaxValueItem[data-reactid='.0.1.0.1.$个税.1']").text
    

    fujia_tax = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, "div.secondTaxValueItem[data-reactid='.0.1.0.1.$增值税附加.1']"))
    ).text

    if zengzhi_tax == "免征" and fujia_tax == "免征":
        total_zengzhi_tax = "免征"
    elif zengzhi_tax == "免征":
        total_zengzhi_tax = fujia_tax
    elif fujia_tax == "免征":
        total_zengzhi_tax = zengzhi_tax
    else:
        # 将增值税和增值税附加合并
        total_zengzhi_tax ="￥" + str(float(zengzhi_tax.replace("￥", "")) + float(fujia_tax.replace("￥", "")))
    compare_and_print("契税", deed_tax, qishui)
    compare_and_print("增值税", value_added_tax_result, total_zengzhi_tax)
    compare_and_print("个税", income_tax, geshui)
    print("契税",qishui)
    print("增值税",total_zengzhi_tax)
    print("个税",geshui)
    print("-------------------")
    # 关闭浏览器

    return 1


def compare_and_print(discrepancy_name, calculated_value, web_value):
    """
    比较计算值和网页值，打印出不匹配的项
    """
    # 将网页读取的数值去掉 "￥" 并转成浮点数
    web_value_num = float(web_value.replace("￥", "")) if web_value != "免征" else 0
    # 只在不匹配时打印
    if (calculated_value == None):
        print("-------------------ERRROR-------------------")
        print(f"{discrepancy_name} 计算值报错，网页值 = {web_value}")
        print("-------------------ERRROR-------------------")
    elif abs(calculated_value - web_value_num) > 1:  # 允许微小误差
        print("-------------------ERRROR-------------------")
        print(f"{discrepancy_name} 不匹配：计算值 = {calculated_value}, 网页值 = {web_value}")
        print("-------------------ERRROR-------------------")


# 从文件读取数据
def read_data(file_path):
    data = []
    with open(file_path, 'r') as file:
        for line_num, line in enumerate(file, start=1):  # 使用enumerate获取行号，从1开始
            # 将每行数据按空格分割，转换为列表
            values = line.strip().split()

            if len(values) < 7:
                print(f"第{line_num}行数据不完整，跳过此行")
                continue  # 跳过格式不正确的行

            # 获取数据并转换为合适的类型
            buyer_is_first_purchase = int(values[0])  # 买房家庭首套
            house_total_area = float(values[1])  # 房屋面积
            house_total_price = float(values[2])  # 房屋总价
            seller_certificate_time = int(values[3])  # 房产证持有时间
            house_is_urban = int(values[4])  # 房屋区域是否在城区
            seller_is_only_house = int(values[5])  # 卖家是否唯一住房
            if(values[6] == "None"):
                house_original_price = None
            else:
                house_original_price = int(values[6])  # 房屋原值

            # 调用计算函数
            value_added_tax_result = calculate_value_added_tax(seller_certificate_time, house_is_urban, house_total_price)
            print(f"增值税: {value_added_tax_result}")
            
            value_tax = calculate_value_tax(seller_certificate_time, house_total_price)

            deed_tax = calculate_deed_tax(buyer_is_first_purchase, house_total_area, house_total_price, value_tax)
            print(f"契税: {deed_tax}")

            income_tax = calculate_income_tax(house_total_price, house_original_price, seller_certificate_time, seller_is_only_house, value_added_tax_result)
            print(f"个税: {income_tax}")
            
            if(house_original_price == None):
                house_original_price = 0       
            a = test(buyer_is_first_purchase, seller_is_only_house, seller_certificate_time, house_total_area, house_total_price/10000, house_original_price/10000, deed_tax, value_added_tax_result, income_tax)

            print(f"处理了第{line_num}行数据")  # 打印处理了哪一行

            print()  # 打印空行分隔每一组数据

    return 1





# 配置 WebDriver，假设使用 Chrome 浏览器
driver = webdriver.Chrome() 

# 打开目标网站
driver.get('https://bj.ke.com/tool.html?sub=1')  # 替换为实际的网址

# 等待页面加载完成（如果需要）
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'mainContent')))
# 假设文件路径为 data.txt
file_path = 'data.txt'
data = read_data(file_path)
driver.quit()